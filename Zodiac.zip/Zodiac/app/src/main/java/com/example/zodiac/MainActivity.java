package com.example.zodiac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MainActivity extends AppCompatActivity {



    EditText editTextMonth;
    EditText editTextDay;
    EditText editTextYear;

    Button buttonClear;
    Button buttonValidate;
    Button buttonZodiac;

    int inputDay;
    int inputMonth;
    int inputYear;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextDay = findViewById(R.id.editTextDay);
        editTextMonth = findViewById(R.id.editTextMonth);
        editTextYear = findViewById(R.id.editTextYear);

        buttonClear = findViewById(R.id.buttonClear);
        buttonValidate = findViewById(R.id.buttonValidate);
        buttonZodiac = findViewById(R.id.buttonZodiac);
        buttonZodiac.setEnabled(false);



        buttonValidate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String day = editTextDay.getText().toString();
                String month = editTextMonth.getText().toString();
                String year = editTextYear.getText().toString();

                boolean keepGoing = true;
                if (keepGoing) {
                    keepGoing = validateInputMonth();
                    if (( Integer.parseInt(month) >= (1)) || ( Integer.parseInt(month) <= 12)){
                        keepGoing = true;
                    }
                    else{
                        keepGoing= false;
                        buttonZodiac.setEnabled(false);
                        Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number Must Be Between (01-12)",Toast.LENGTH_LONG);
                    }
                }



                if (keepGoing) {
                    keepGoing = validateInputYear();
                    if (( Integer.parseInt(year) >= (1890)) || ( Integer.parseInt(year) <= 2020)){
                        keepGoing = true;
                    }
                    else{
                        keepGoing= false;
                        buttonZodiac.setEnabled(false);
                        Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number Must Be Between (1980-2020)",Toast.LENGTH_LONG);
                    }
                }




                if (keepGoing) {
                    keepGoing = validateInputDay();

                    if ( Integer.parseInt(month) == 2)
                    {
                        if ( Integer.parseInt(year) % 4 == 0)
                        {
                            if ( Integer.parseInt(day) >= 29)
                            {
                                keepGoing = true;
                            }
                            else
                            {
                                Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number Must Be Between (01-29)",Toast.LENGTH_LONG);
                                keepGoing = false;
                                buttonZodiac.setEnabled(false);

                            }
                        }
                        else{
                            if ( Integer.parseInt(day) >= 28)
                            {
                                keepGoing = true;
                            }
                            else
                            {
                                Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number Must Be Between (01-28)",Toast.LENGTH_LONG);
                                keepGoing = false;
                                buttonZodiac.setEnabled(false);

                            }
                        }
                    }
                    else if (( Integer.parseInt(month) % 2 == 0 ) || ( Integer.parseInt(month) >= 12)){
                      if ( Integer.parseInt(day) >= 31){
                          keepGoing = true;
                      }
                      else
                      {
                          Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number Must Be Between (01-31)",Toast.LENGTH_LONG);
                          keepGoing = false;
                          buttonZodiac.setEnabled(false);

                      }
                    }
                    else if (( Integer.parseInt(month) % 2 != 0 ) || ( Integer.parseInt(month) >= 12)){
                        if ( Integer.parseInt(day) >= 30){
                            keepGoing = true;
                        }
                        else
                        {
                            Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number Must Be Between (01-30)",Toast.LENGTH_LONG);
                            keepGoing = false;
                            buttonZodiac.setEnabled(false);

                        }
                    }
                    else{
                        keepGoing = false;
                        buttonZodiac.setEnabled(false);
                    }

                }
                if (keepGoing) {


                    Toast toast = Toast.makeText(getApplicationContext(),"Input was good",Toast.LENGTH_LONG);
                    Calendar calendar = Calendar.getInstance();
                    String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
                    buttonZodiac.setEnabled(true);
                }
            }
        });

        buttonZodiac.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                editTextDay.setText("");
                editTextMonth.setText("");
                editTextYear.setText("");
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                editTextDay.setText("");
                editTextMonth.setText("");
                editTextYear.setText("");
                buttonZodiac.setEnabled(false);
            }
        });



/*
        Calendar validDate = new GregorianCalendar();
        validDate.setTime(strDate);
        if (Calendar.getInstance().after(validDate)) {
            catalog_outdated = 1;
*/
    }


    private boolean validateInputDay(){
        try {
            inputDay = Integer.parseInt(editTextDay.getText().toString());

            return true;
        }
        catch (NumberFormatException nfe){
            Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number",Toast.LENGTH_LONG);
            toast.show();
            return false;
        }
    }

    private boolean validateInputMonth(){
        try {
            inputMonth = Integer.parseInt(editTextMonth.getText().toString());
            return true;
        }
        catch (NumberFormatException nfe){
            Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number",Toast.LENGTH_LONG);
            toast.show();
            return false;
        }
    }

    private boolean validateInputYear(){
        try {
            inputYear = Integer.parseInt(editTextYear.getText().toString());
            return true;
        }
        catch (NumberFormatException nfe){
            Toast toast = Toast.makeText(getApplicationContext(),"Bad Input Number",Toast.LENGTH_LONG);
            toast.show();
            return false;
        }
    }
}
